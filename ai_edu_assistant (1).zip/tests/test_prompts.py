from prompts.cot_prompt import cot_prompt

def test_cot_prompt():
    q = "What is 2+2?"
    result = cot_prompt(q)
    assert "Let's think step by step" in result
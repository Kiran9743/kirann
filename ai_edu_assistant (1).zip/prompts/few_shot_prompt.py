def few_shot_prompt(question):
    examples = """
Q: What is 12 + 8?
A: 12 + 8 = 20

Q: What is the capital of France?
A: Paris

Q: What is the boiling point of water in Celsius?
A: 100°C
"""
    return examples + f"\nQ: {question}\nA:"
def cot_prompt(question):
    return f"""Q: {question}
Let's think step by step."""
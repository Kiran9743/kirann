from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import TextLoader

def build_rag():
    loader = TextLoader("docs/education_facts.txt")
    documents = loader.load()
    texts = CharacterTextSplitter(chunk_size=1000).split_documents(documents)
    db = FAISS.from_documents(texts, OpenAIEmbeddings())
    return db

def answer_with_context(query, db):
    docs = db.similarity_search(query)
    return "\n".join([doc.page_content for doc in docs])
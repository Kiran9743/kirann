def run_calc(expression):
    try:
        return str(eval(expression))
    except:
        return "Error in calculation."
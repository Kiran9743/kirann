from duckduckgo_search import ddg

def run_search(query):
    results = ddg(query, max_results=1)
    return results[0]['body'] if results else "No result found."
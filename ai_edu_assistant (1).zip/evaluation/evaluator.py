from openai import OpenAI

def evaluate_models(question, models=["gpt-4", "gpt-3.5-turbo"]):
    responses = {}
    for model in models:
        response = OpenAI(model=model).complete(prompt=question)
        responses[model] = response
    return responses
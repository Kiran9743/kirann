# AI-Powered Educational Assistant

This project uses LLMs like GPT-4 to answer educational questions, with prompt engineering, LangChain agents, RAG for hallucination prevention, and model evaluation support.
from langchain.agents import initialize_agent, Tool
from langchain.chat_models import ChatOpenAI
from tools.search_tool import run_search
from tools.calculator import run_calc

llm = ChatOpenAI(model_name="gpt-4")

tools = [
    Tool(name="SearchTool", func=run_search, description="Search general info"),
    Tool(name="Calculator", func=run_calc, description="Do math calculations")
]

agent = initialize_agent(tools, llm, agent="zero-shot-react-description", verbose=True)

def answer_question(query):
    return agent.run(query)